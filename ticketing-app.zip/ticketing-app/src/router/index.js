import Vue from "vue";
import VueRouter from "vue-router";
// import Home from "../views/Home.vue";
import Landingpage from "../components/Landingpage"
import { store } from './store';

Vue.use(VueRouter);

const routes = [
  {
    path: "",
    name: "Home",
    component: Landingpage
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue")
  },
  {
    path: '/signin',
    name: 'Signin',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Signin.vue')
  },
  {
    path: '/signup',
    name: 'Signup',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Signup.vue')
  },
  {
    path: '/admin',
    name: 'Admin',
    beforeEnter: (to, from, next) => {
      const isAuthenticated = store.state.isAuthenticated;
      if(to.name !== 'Signin' && isAuthenticated === false) next({name:'Signin'})
      else next()
    },
    component: () => import('../components/Admin.vue'), children: [
      {
        path: '', 
        name: 'AdminHome',
        component: () => import('../components/admin/AllTicketsAdmin.vue')
      },
      {
        path: ':id',
        name: 'AdminDetail',
        component: () => import('../components/admin/TicketDetailAdmin.vue')
      },
      {
        path: 'priority', 
        name: 'Priority',
        component: () => import('../components/admin/Priority.vue')
      },
      {
        path: 'status', 
        name: 'Status',
        component: () => import('../components/admin/Status.vue')
      },
      {
        path: 'moderators', 
        name: 'Moderator',
        component: () => import('../components/admin/Moderators.vue')
      },
      {
        path: 'basics', 
        name: 'Basics',
        component: () => import('../components/admin/BasicUsers.vue')
      },
    ]
  },
  {
    path: '/basic',
    name: 'Basic',
    beforeEnter: (to, from, next) => {
      const isAuthenticated = store.state.isAuthenticated;
      if(to.name !== 'Signin' && isAuthenticated === false) next({name:'Signin'})
      else next()
    },
    component: () => import('../components/basic/bNav.vue'), children:[
      {
        path: '',
        name: 'createTicket',
        component: () => import('../components/basic/CreateTicket.vue')
      },  
      {
        path: ':id',
        name: 'checkStatus',
        component: () => import('../components/basic/CheckTicketStatus.vue')
      },
      {
        path: 'list-tickets',
        name: 'listTicket',
        component: () => import('../components/basic/ListOfTicket.vue')
      }
    ]
  },
  {
    path: '/moderator',
    name: 'Moderator',
    beforeEnter: (to, from, next) => {
      const isAuthenticated = store.state.isAuthenticated;
      if(to.name !== 'Signin' && isAuthenticated === false) next({name:'Signin'})
      else next()
    },
    component: () => import('../components/moderator/mNav.vue'), children: [
      {
        path: '',
        name: 'ModeHome',
        component: () => import('../components/moderator/ListOfMticket.vue')
      },
      {
        path: ':id',
        name: 'ModeDetail',
        component: () => import('../components/moderator/CheckMticketStatus.vue')
      }
    ]
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
