<template>
  <v-app>
    <Navbar/>
    <v-main id="sign">
      <!-- <Admin /> -->
    <!-- <Home v-show="admin == true" /> -->
    <!-- <Signin/> -->
    <router-view></router-view>
    <!-- <Admin msg="Welcome to Your Vue.js App" v-show="admin == true" /> -->
    </v-main>
  </v-app>
</template>

<script>
//import Admin from "./components/Admin";
// import Home from "./views/Home.vue";
// import Admin from "@/components/Admin.vue";
// import Signin from "./views/Signin.vue";
import Navbar from './views/Navbar'
export default {
  name: "App",

  components: {
  //  Admin,
  // Home,
  // Signin
  Navbar
  },

  data: () => ({
      
  })
};
</script>
<style scoped>

</style>

