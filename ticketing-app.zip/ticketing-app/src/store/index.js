import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export const store = new Vuex.Store({
  state: {
		accessToken: '',
		user: {},
    isAuthenticated: false,
		role:'',
		tickets: [],
		allTickets: [],
		allMTickets: [],
		dallTickets: [],
		ticketWithHandler: [],
		allUsers:[],
		priority:[],
		status:[]
	},
	mutations: {
		setAccessToken: (state, value) => {
			state.accessToken = value;
		},
		setUser: (state, value) => {
			state.user = value;
		},
		authenitcate: (state) => {
			state.isAuthenticated = true;
    },
    setRole:(state, value) => {
      state.role = value
		},
		setTickets: (state, value) => {
			state.tickets = value
		},
		setAllTickets: (state, value) => {
			state.allTickets = value
		},
		setAllMTickets: (state, value) => {
			state.allMTickets = value
		},
		ticketForDetail: (state, value) => {
			state.dallTickets = value
		},
		setTwith: (state, value) => {
			state.ticketWithHandler = value
		}, 
		setUsers: (state, value) => {
			state.allUsers = value
		},
		allPriority: (state, value) => {
			state.priority = value
		},
		allStatus: (state, value) => {
			state.status = value
		}
	},
	actions: {
		login: async ({commit, state}, credentials) => {
			try {
				const response = await fetch('http://127.0.0.1:8000/api/login', {
					method: 'POST',
					body: JSON.stringify(credentials),
					headers: {
						'Content-Type': 'application/json',
					},
				});
				const data = await response.json();
				//const { accessToken } = data.access_token;
				commit('setAccessToken', data.token);
				commit('setUser', data.user);
				commit('authenitcate');
				commit('setRole', data.$userRole.role); 

				state.isAuthenticated = true
				
			} catch (err) {
				return console.log(err);
			}		
		},
		createticket: async ({ state },ticket) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/create-ticket',{
					method: 'POST',
					body: JSON.stringify(ticket),
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data  = await response.json();
				console.log(data.message)
			} catch (err) {
				return console.log("ERRORRRR ",err)
			}
		},
		getAllUsers: async({ commit, state }) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/users',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('setUsers', data.list_of_user)
			} catch (err){
				return console.log("ERRORRR showing", err)
			}
		},
		getAllPriority: async({ commit, state }) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/priority',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('allPriority', data.priority)
			} catch (err){
				return console.log("ERRORRR showing", err)
			}
		},
		getAllStatus: async({ commit, state }) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/status',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('allStatus', data.statuses)
			} catch (err){
				return console.log("ERRORRR showing", err)
			}
		},
		listticket: async ({ commit, state }) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/show-ticket',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('setTickets', data.tickets)
				commit('setTwith', data.twith)
				console.log("DAATAA ", data.tickets)
			} catch (err){
				return console.log("ERRORRR showing", err)
			}
		},
		listallticket: async({commit, state}) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/all-ticket',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('setAllTickets', data.tickets)
				commit('ticketForDetail', data.detickets)
				
				console.log(state.open,'  ', state.pending, '  ', state.closed) 
			}catch(err){
				return console.log('ERRORR ', err)
			}
		},
		mlistallticket: async({commit, state}) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/mall-ticket',{
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer '+ state.accessToken,
					}
				});
				const data = await response.json();
				commit('setAllMTickets', data.tickets)
				console.log(state.open,'  ', state.pending, '  ', state.closed) 
			}catch(err){
				return console.log('ERRORR ', err)
			}
		},
		logout:async({state}) => {
			try{
				const response = await fetch('http://127.0.0.1:8000/api/logout',{
						method: 'GET',
						headers: {
							'Content-Type': 'application/json',
							'Authorization': 'Bearer '+ state.accessToken,
						}
					});
					const data = await response.json()
					console.log("Logging out ", data.message)
					state.accessToken = null;
					state.isAuthenticated = false
			}catch(err){
				return console.log("Error while loginout")
			}
		},
	},
	
  modules: {}
});
