<template>
  <div class="home"> 
    <!-- <Signin v-show="sign == true"/> -->
    <Admin msg="Welcome to Your Vue.js App" v-show="admin == true" />
  </div>
</template>

<script>
// @ is an alias to /src
import Admin from "@/components/Admin.vue";
// import Signin from "./Signin.vue";

export default {
  name: "Home",
  components: {
    Admin,
    // Signin
  },
  data(){
    return{
      admin: true,
      sign: false,
    }
  }
};
</script>
