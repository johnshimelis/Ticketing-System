<template>
	<div> 
		<div id="chat_box" class="chat_box pull-right" >
      <div class="row">
        <div class="col-xs-12 col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading" style="padding-left:6px;padding-top:6px">
                        <h6 class="panel-title"><span class="glyphicon glyphicon-comment"></span> Any question .. <i class="chat-user"></i> </h6>
                        <span class="glyphicon glyphicon-remove pull-right close-chat"></span>
                    </div><hr/>
                    <div class="chat-area" id="container">
											<ul class='list-unstyled' style='overflow-y:scroll'>
												<li 
													class="p-2" 
													v-for="message in conversations" 
													:key="message.index"
													:class="[message.from == user.id ? 'me': '']"
													>

													{{ message.message }}
												
												</li>								
											</ul>
                    </div>
                    
                </div>
        </div>
      </div> 
			
    </div>
		<div class="panel-footer" id="sender">
                        <div class="input-group form-controls">
                          <textarea
														class="form-control input-sm chat_input"
														placeholder="Write your message here..."
														@keyup.enter="sendMessage"
														v-model="message"
														name="message"
															>
														</textarea>
                        </div>
                    </div>
	</div>
</template>

<script>
	import axios from 'axios';
	
	export default{
		props:['touser','fromuser'],
		data(){
			return {
				message: '',
				channel:'',
				conversations:[],
				to_user_id:'',
				token:'',
				user:this.$store.state.user,
				name: '',
			}
		},
		
		mounted(){
			this.token = this.$store.state.accessToken;
			window.Echo.channel('chat')
				.listen('MessageSent', (e) => {
					console.log("MESS ==> ",e.message)
					if(this.user.id == e.message.to_user || this.user.id == e.message.from_user){	
							this.conversations.push({
								message: e.message.message,
								from: e.message.from_user,
								to: e.message.to_user
						})
						console.log( this.message)
					}
				})
			//this.fetchMessages()
		},
		
		methods: {
			scrollToEnd: function() {    	
         var container = this.$el.querySelector("#container");
         container.scrollTop = container.scrollHeight;
      },
			fetchMessages(){
				axios.get('http://127.0.0.1:8000/api/get-message',
				{	
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer ' + this.token
					}})
					.then(response => {
						this.conversations = response.data.message;
						// console.log(this.conversations)
					})
			},

			sendMessage(){
				// this.conversations.push({
				// 	user: this.user,
				// 	message: this.message
				// })
				axios.post('http://127.0.0.1:8000/api/send-message', {
					message: this.message,
					to_user: this.touser,
					from_user: this.fromuser
				},	
				{	
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer ' + this.token
					}
				})
				.catch((error) => {
					console.log("AnoyinG",error)
				})
				this.scrollToEnd();
				this.message = ''
			}

		}
	}
</script>

<style scoped>
#sender{
	margin-top: 14px;
}
.me{
	background-color: #4bdbe6;
	margin-bottom: 10px;;
}
p {
    font-size: 13px;
    padding: 5px;
    border-radius: 3px;
}

.base_receive p {
    background: #4bdbe6;
}

.base_sent p {
    background: #e674a8;
}

time {
    font-size: 11px;
    font-style: italic;
}

#login-box {
    margin-top: 20px
}

#chat_box {
	/* background-color:rgb(209, 223, 240); */
	border-style: groove; 
    /* position: fixed;
    top: 10%;
    right: 5%;
    width: 27%; */
}

.close-chat {
    margin-top: -17px;
    cursor: pointer;
}

.chat_box {
    margin-right: 25px;
    width: 366px;
}

.chat-area {
		padding: 24px;
    height: 250px;
    overflow-y: scroll;
}

#users li {
    margin-bottom: 5px;
}

#chat-overlay {
    position: fixed;
    right: 0%;
    bottom: 0%;
}

.glyphicon-ok {
    color: #42b7dd;
}

.loader {
    -webkit-animation: spin 1000ms infinite linear;
    animation: spin 1000ms infinite linear;
}

</style>