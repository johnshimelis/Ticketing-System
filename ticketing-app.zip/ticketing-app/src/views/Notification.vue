<template>
	<li class="dropdown">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
			<span class="glyphicon glyphicon-globe"></span>
			Notifications
			<span class="badge">3</span>
		</a>
	</li>
</template>