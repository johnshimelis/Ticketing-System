<template>
	<div>
		<!-- <Navbar></Navbar><hr/> -->

			<div class="container">
				<div class="myform form">
					<div class="logo mb-3">
						<div class="col-md-12 text-center">
						<h1>Sign up</h1>
				</div>
			</div>
				<form @submit.prevent="submit">

				<v-text-field
            v-model="user.name"
             :rules="[rules.required, rules.emailMatch]"
            label="Name"
            hide-details="auto"
          ></v-text-field>

				<v-text-field
            v-model="user.email"
             :rules="[rules.required, rules.emailMatch]"
            label="Email"
            hide-details="auto"
          ></v-text-field>

				<v-text-field
            v-model="user.password" 
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="[rules.required, rules.min]"
            :type="show1 ? 'text' : 'password'"
            name="input-10-1"
            label="Password"
            hint="At least 8 characters"
            counter
            @click:append="show1 = !show1"
          ></v-text-field>
				<div class="col-md-4 text-center mb-3" style="float:right">
          <button type="submit" class=" btn btn-block btn-primary ">submit</button>
        </div> 
			</form>
				</div>			
		</div>
	</div>
</template>

<script>
// import Navbar from '../../components/Navbar.vue'
export default {
	name: 'login',
  components:{
    // Navbar
  },
	data() {
		return{
			show1: false,
			user: {
				name:'',
        email: '',
				password: '',
			},
			rules: {
        required: value => !!value || 'Required.',
          min: v => v.length >= 8 || 'Min 8 characters',
          emailMatch: () => (`The email and password you entered don't match`),
    },
		}
	},

	methods: {
		submit(){
			fetch('http://127.0.0.1:8000/api/register',{
				method: 'POST',
				body: JSON.stringify(this.user),
				headers:{
					'Content-Type': 'application/json',
				}
			})
				.then(response => response.json())
				.then((data) => {
					console.log(data);
					this.$router.replace('/login');
				})
		},
	},
}
</script>


<style scoped>
   .myform{ 
		margin: auto;
		position: relative;
		display: -ms-flexbox;
		display: flex;
		margin-top: 100px;
		padding: 1rem;
		-ms-flex-direction: column;
		flex-direction: column;
		width: 100%;
		pointer-events: auto;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid rgba(0,0,0,.2);
		border-radius: 1.1rem;
		outline: 0;
		max-width: 500px;
	}

	.tx-tfm{
    text-transform:uppercase;
  }
</style>		