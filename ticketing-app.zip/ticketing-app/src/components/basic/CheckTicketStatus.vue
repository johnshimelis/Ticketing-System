<template>
<div class="row">
<div class="column" id="table-tick">
  <v-simple-table style="width:700px;">
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">
            Ticket #4
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Title</td>
          <td>{{ ticket.title }}</td>
        </tr>
				<tr>
          <td>Content</td>
          <td>{{ ticket.description }}</td>
        </tr>
				<tr>
          <td>Status</td>
          <td>{{ ticket.status }}</td>
        </tr>
				<tr>
          <td>Auther name</td>
          <td>{{ user.name }}</td>
        </tr>
				<tr>
          <td>Auther Email</td>
          <td>{{ ticket.sender_email }}</td>
        </tr>
				<tr>
          <td>Comment</td>
          <td>{{ ticket.comment }}</td>
        </tr>
      </tbody>
    </template>
  </v-simple-table>
</div>	
<div class="column" id="chat">
   <Chat :touser="to_user" :fromuser="from_user"/>
 </div>
</div>
</template>

<script>
import Chat from '../../views/Chat.vue'
  export default {
    components: {
       Chat
    },
    data () {
      return {
        id: this.$route.params.id,
        ticket: {},
        user:this.$store.state.user,
        tickets: [],
        to_user:0,
        from_user:0,
      }
    },
    mounted(){
      this.tickets = this.$store.state.tickets 
      this.from_user = this.$store.state.user.id
      this.tickets.forEach(element => {
        if(element.id == this.id){
          this.ticket = element
        }
      });
      this.twithandler = this.$store.state.ticketWithHandler
      this.twithandler.forEach(element => {
        if(element.id == this.id){
          this.to_user = element.handler_user_id
        }
      })
      console.log("MY TICK", this.ticket)
    },
  }
</script>
<style scoped>
#table-tick{
	margin: auto;
	margin-top: 25px;
	width: 66%;

}
#chat{
	margin-top: 45px;
	width: 24%;
	position: relative;
	right:10%;
}
</style>