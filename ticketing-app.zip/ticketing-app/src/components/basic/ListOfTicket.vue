<template>
<div id='table-tick'>
  <v-simple-table>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">
            Title
          </th>
          <th class="text-left">
            Content
          </th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="item in tickets"
          :key="item.name"
        >
          <td>{{ item.title }}</td>
          <td v-if="item.description !== null" @click="goTodetail(item.id)">
             <a> {{ item.description }}</a>
          </td>
          <td v-else @click="goTodetail(item.id)">
             <a> {{ "No description was added" }} </a>
          </td> 
                      
        </tr>
      </tbody>
    </template>
  </v-simple-table>
</div>
</template>

<script>
import { mapActions } from 'vuex';
  export default {
    data () {
      return {
        tickets: [],
      }
    },
    mounted(){
      this.showTicket()
      console.log("LIST OF TIDK")
    },
    methods: {
      ...mapActions([
			'listticket',
			]),
      showTicket(){
        this.listticket()
          .then(() => {
            this.tickets = this.$store.state.tickets 
            console.log(this.$store.state.tickets)
            console.log("Success")
          })
      },
      goTodetail(itemid) {
        this.$router.replace({name:'checkStatus',params:{id:itemid}})
      }
    },
  }
</script>
<style scoped>
#table-tick{
	margin: auto;
	margin-top: 25px;
	width: 66%;

}
</style>