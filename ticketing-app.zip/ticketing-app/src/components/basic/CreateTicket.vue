<template>
	<div>
		<div class="myform form ">
			<div class="logo mb-3">
				<div class="col-md-12 text-center">
					<h1>Create Your ticket here.</h1>
				</div>
			</div>
	
			<form @submit.prevent="postTicket">

        <div>
          <v-text-field
            v-model="ticket.title"
             :rules="[rules.required]"
            label="Ticket title"
            hide-details="auto"
          ></v-text-field>
					<v-container fluid>
					<v-textarea
						v-model="ticket.description"
							name="input-7-1"
							filled
							label="Description"
							auto-grow
						></v-textarea>
					</v-container>
					<v-text-field
            v-model="ticket.sender_email"
            :rules="[rules.required]"
            label="Your email"
            hide-details="auto"
          ></v-text-field>
         
        </div>
				<div class="col-md-4 text-center mb-3" style="float:right;margin-top:3px;">
          <button type="submit" class=" btn btn-block btn-primary ">submit</button>
        </div> 
			</form> 
			</div>
			<div id="retr">
				<a @click="getTickets()"> Retrieve your sent ticket </a> 
			</div>
		</div>
</template>

<script>
import { mapActions } from 'vuex';
export default {

	name: 'createticket',
	data() {
		return{
			show1: false,
			token: '',
			ticket: {
        title: '',
				description: '',
				sender_email: '',
			},
      user:{},
      rules: {
        required: value => !!value || 'Required.',
      },
		}
	},
	mounted(){
			this.token = this.$store.state.accessToken;
			if(this.token !== null){
				this.ticket.sender_email = this.$store.state.user.email
			}
  }, 
	methods: {
		...mapActions([
			'createticket',
			]),
		getTickets(){
          this.$router.push({name:'listTicket'})
			},
		postTicket: function(){
				this.createticket(this.ticket)
					.then(() => {
						this.ticket.title = ''
						this.ticket.description = ''
						alert('Your ticket has been sent')
				})
				
		}		
	},

}
</script>

<style scoped>
#retr{
	margin-left: 46%;
	margin-top: 3%;
	color: blue;
}
   .myform{ 
    margin: auto;
		display: flex;
		margin-top: 70px;
		padding: 1rem;
		-ms-flex-direction: column;
		flex-direction: column;
		width: 100%;
		pointer-events: auto;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid rgba(0,0,0,.2);
		border-radius: 1.1rem;
		outline: 0;
		max-width: 500px; 
   }

</style>