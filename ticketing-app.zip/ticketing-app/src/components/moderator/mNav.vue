<template>
<div>
	<v-app-bar app color="primary" dark id="app-barv" >
       <a><div class="d-flex align-center">
				<span class="mr-2" id="logot">Ticketing.io</span>
      </div></a>

      <v-spacer></v-spacer>

      <v-btn
        target="_blank"
        text
      >
        <span class="mr-2">Sign out</span>
  
      </v-btn>
    </v-app-bar>
		<router-view></router-view>
</div>
</template>
<style scoped>
#logot{
  font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  font-weight: bolder;
  font-size: 150%;
}
</style>