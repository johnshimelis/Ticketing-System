<template>
<div class="row">
 <div class="column" id="table-tick">
  <v-simple-table style="width: 800px;">
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">
            Ticket # {{ ticketId }}
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Title</td>
          <td>{{ ticket.title }}</td>
        </tr>
				<tr>
          <td>Content</td>
          <td>{{ ticket.description }}</td>
        </tr>
				<tr>
          <td>Status</td>
          <td>{{ ticket.status }}</td>
        </tr>
				<tr>
          <td>Proirity</td>
          <td>{{ ticket.priority }}</td>
        </tr>
				<tr>
          <td>Auther Email</td>
          <td>{{ ticket.sender_email }}</td>
        </tr>
				<tr>
          <td>Handler Name</td>
          <td>{{ ticket.handler_user_id }}</td>
        </tr>
				<tr>
          <td>Comment</td>
          <td>{{ comment_text }}</td>
        </tr>
      </tbody>
    </template>
  </v-simple-table>
	<div >
		<br>
			<div id="Container" v-if="editable"> 
					<div class="row"> 
						<div class="col-sm">   
								<label class="content">Only add comment if the ticket is handled: </label>
								<div  class="form-group" style="width:500px;" >
									<textarea v-model='comment_text' class="form-control" rows="3" cols="200" style="width:500px;" ></textarea>
								</div>
						</div>
						<div style="margin-top:30px;">
							<v-btn color="primary" @click='addComment' >
								Add Comment
              </v-btn>   
						</div>
					</div>
     </div>
	</div>
 </div>	
 <div class="column" id="chat">
   <Chat :touser="to_user" :fromuser="from_user"/>
 </div>
</div>
</template>

<script>
import Chat from '../../views/Chat.vue'
  export default {
    components: {
       Chat
    },
    data () {
      return {
        id: this.$route.params.id,
        ticket: {},
        user:{},
				tickets: [],
				editable: true,
        comment_text : '',
        to_user:0,
        from_user:0,
        ticketId: 0,
				comment: {}
      }
    },
    mounted(){
      this.tickets = this.$store.state.allMTickets 
      this.user = this.$store.state.user
      
      this.from_user = this.user.id
      

      this.ticket = this.tickets.filter(ticket => ticket.id == this.id)[0]
      this.ticketId = this.ticket.id
      this.to_user = this.ticket.sender_id
      this.getComment()
		},
		methods: {
      getComment: function(){
        fetch('http://127.0.0.1:8000/api/comment/'+this.ticketId,{
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer '+ this.$store.state.accessToken,
            }
        })
          .then(response => response.json())
          .then((data) => {
              this.comments = [...data.comms]
              if(this.comments.length == 0){
                 this.editable = false
              }
              if(this.comments.length == 1){
                this.comment_text = this.comments[0].comment_text
              }else if(this.comments.length == 2){
                this.comment_text = this.comments[1].comment_text
                this.editable = false
              }
          })  
        },
			addComment: function(){
				this.comment.comment_text = this.comment_text
				this.comment.writter_name = this.user.name,
        this.comment.writter_email = this.user.email,
        this.comment.ticket_id  = this.ticket.id,
        this.comment.user_id = this.user.id
				
        fetch('http://127.0.0.1:8000/api/add-comment',{
            method: 'POST',
            body: JSON.stringify(this.comment),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer '+ this.$store.state.accessToken,
            }
        })
          .then(response => response.json())
          .then((data) => {
							if(data.status == 200) { alert('Content updated');}
             // this.$router.push({name:'AdminHome'})
              alert("Comment Added")
              this.editable = false
          })  
        },
			}
  }
</script>
<style scoped>
#table-tick{
	margin: auto;
	margin-top: 25px;
	width: 66%;

}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
#chat{
	margin-top: 55px;
	width: 24%;
	position: relative;
	right:6%;
}
</style>