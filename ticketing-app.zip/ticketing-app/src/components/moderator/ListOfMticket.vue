<template>
	<div style="margin-top:40px;">
  <v-card 
      style='width:900px; margin:auto;'>
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="tickets"
      :search="search"
    >
		

		<template v-slot:top>
        <v-dialog
          v-model="dialog"
          max-width="500px"
        >
          <v-card>
            <v-card-title>
              <span class="headline">{{ formTitle }}</span>
            </v-card-title>

            <v-card-text>
              <v-container>
                <v-row>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
										:disabled=true
                      v-model="editedItem.status"
                      label="Ticket Status"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
										:disabled=true
                      v-model="editedItem.priority"
                      label="Ticket Priority "
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
										:disabled=true
                      v-model="editedItem.handler_user_id"
                      label="Ticket Handler"
                    ></v-text-field>
                  </v-col>
                  
                </v-row>
              </v-container>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn
                color="blue darken-1"
                text
                @click="close"
              >
                Cancel
              </v-btn>
              <v-btn
                color="blue darken-1"
                text
                @click="view"
              >
                View
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="dialogDelete" max-width="500px">
          <v-card>
            <v-card-title class="headline">Are you sure you want to delete this item?</v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
              <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
              <v-spacer></v-spacer>
            </v-card-actions>
          </v-card>
        </v-dialog>
    </template>
    <template v-slot:[`item.actions`]="{ item }">
      <v-icon
        small
        class="mr-2"
        @click="editItem(item)"
      >
        mdi-pencil
      </v-icon>
      <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon>
    </template>
		</v-data-table>
  </v-card>
	</div>
</template>

<script>
import { mapActions } from 'vuex';
  export default {
    data () {
      return {
				tickets:[],
        search: '',
        headers: [
          {
            text: 'Title',
            align: 'start',
            filterable: true,
            value: 'title',
          },
          { text: 'Status', value: 'status' },
          { text: 'Priority', value: 'priority' },
          { text: 'Sender Email', value: 'sender_email' },
					{ text: 'Handler Id', value: 'handler_user_id' },
					{ text: 'Actions', value: 'actions', sortable: false },
				],
				editedIndex: -1,
        editedItem: {
           priority_id: 0,
           status_id: 0,
           handler_user_id: 0,
				},
				valueOfid: 0,
				dialog: false,
        dialogDelete: false,
				formTitle: 'Ticket Status'
      }
		},
		mounted(){
			this.showTicket()
		},
		methods: {
			...mapActions([
			'mlistallticket',
			]),
      showTicket(){
        this.mlistallticket()
          .then(() => {
            this.tickets = this.$store.state.allMTickets 
            console.log(this.$store.state.allMTickets)
            console.log("Success")
          })
			},
			

      editItem (item) {
        this.editedIndex = this.tickets.indexOf(item)
        this.editedItem = Object.assign({}, item)
				this.dialog = true
				this.valueOfid = item.id
				console.log(item.id)
      },
      deleteItem (item) {
        this.editedIndex = this.tickets.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },
      deleteItemConfirm () {
        this.tickets.splice(this.editedIndex, 1)
        this.closeDelete()
      },
      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },
      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },
      view () {
        if (this.editedIndex > -1) {
					Object.assign(this.tickets[this.editedIndex], this.editedItem)
        }
				this.close()
				this.$router.push({name: 'ModeDetail', params:{id:this.valueOfid}})
      },
		},

		watch: {
      dialog (val) {
        val || this.close()
      },
      dialogDelete (val) {
        val || this.closeDelete()
			},
			'$route'(to){
				this.$id = to.params.id
			}
    },

  }
</script>