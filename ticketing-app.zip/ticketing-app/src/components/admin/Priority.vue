<template>
	<div>
		<div style="margin-left:9px;">
			<div style="margin-left:5%;">Priorities</div>
      <div style="margin-bottom:18px;">
      </div>
		</div>
  <v-card
    style='width:1100px; margin:auto;'>
    <v-card-title>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="priority"
      :search="search"
    >
		<template v-slot:top>
        <v-dialog
          v-model="dialog"
          max-width="500px"
        >
          <v-card>
            <v-card-title>
              <span class="headline">{{ formTitle }}</span>
            </v-card-title>

            <v-card-text>
              <v-container>
                <v-row>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
                      v-model="editedItem.status_id"
                      label="Ticket Status"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
                      v-model="editedItem.priority_id"
                      label="Ticket Priority "
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    sm="6"
                    md="4"
                  >
                    <v-text-field
                      v-model="editedItem.handler_user_id"
                      label="Ticket Handler"
                    ></v-text-field>
                  </v-col>
                  
                </v-row>
              </v-container>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn
                color="blue darken-1"
                text
                @click="close"
              >
                Cancel
              </v-btn>
              <v-btn
                color="blue darken-1"
                text
                @click="save"
              >
                Edit
              </v-btn>
              <v-btn
                color="blue darken-1"
                text
                @click="view"
              >
                View
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="dialogDelete" max-width="500px">
          <v-card>
            <v-card-title class="headline">Are you sure you want to delete this item?</v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
              <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
              <v-spacer></v-spacer>
            </v-card-actions>
          </v-card>
        </v-dialog>
    </template>
    <template v-slot:[`item.actions`]="{ item }">
      <v-icon
        small
        class="mr-2"
        @click="editItem(item)"
      >
        mdi-pencil
      </v-icon>
      <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon>
    </template>
		</v-data-table>
  </v-card>
	</div>
</template>
<script>
export default {
	data(){
		return {
				search: '',
        headers: [
          {
            text: 'Id',
            align: 'start',
            filterable: true,
            value: 'id',
          },
          { text: 'Name', value: 'name' },
					{ text: 'Actions', value: 'actions', sortable: false },
				],
				editedIndex: -1,
        editedItem: {
           priority_id: 0,
           status_id: 0,
           handler_user_id: 0,
				},
				valueOfid: 0,
				dialog: false,
        dialogDelete: false,
				formTitle: 'Edit Ticket',
				
				priority:[],

				btns: [
         ['Custom', 'b-xl'],
        ],
        colors: ['deep-purple accent-4', 'error', 'teal darken-1'],
        items: [],
		}
	},
	
	mounted(){ 
		const result = this.$store.state.priority
		this.priority = result
	},

	methods: {
		editItem (item) {
        this.editedIndex = this.$store.state.allTickets.indexOf(item)
        this.editedItem = Object.assign({}, item)
				this.dialog = true
				this.valueOfid = item.id
				console.log(item.id)
      },
      deleteItem (item) {
        this.editedIndex =  this.$store.state.allTickets.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },
      deleteItemConfirm () {
         this.$store.state.allTickets.splice(this.editedIndex, 1)
        this.closeDelete()
      },
      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },
      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },
      view(){
        this.$router.push({name: 'AdminDetail', params:{id:this.valueOfid}})
      },
      save () {
        if (this.editedIndex > -1) {
					Object.assign( this.$store.state.allTickets[this.editedIndex], this.editedItem)
					if(this.valueOfid ==  this.$store.state.allTickets[this.editedIndex].id){
						fetch('http://127.0.0.1:8000/api/update-ticket/'+this.valueOfid,{
							method: 'POST',
							body: JSON.stringify(this.editedItem),
							headers: {
								'Content-Type': 'application/json',
								'Authorization': 'Bearer '+ this.$store.state.accessToken,
							}
						})
						.then(response => response.json())
            .then((data) => {
                console.log(data.status);
                this.showTicket()
            })
						console.log('')
					}
        }
				this.close()
      },
		},

		watch: {
      dialog (val) {
        val || this.close()
      },
      dialogDelete (val) {
        val || this.closeDelete()
      },
    },
	
}
</script>