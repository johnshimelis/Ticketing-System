<template>
  <div id="sidepanel">
    <v-navigation-drawer app v-model="drawer" :mini-variant.sync="mini" >
      <v-list-item class="px-2" style="padding-bottom:7px">
        <v-list-item-avatar>
           <v-img class="img-profile rounded-circle" src="@/assets/img/adminlogo.jpg"></v-img>
        </v-list-item-avatar>

        <v-list-item-title>Admin panel</v-list-item-title>

        <v-btn icon @click.stop="mini = !mini">
          <v-icon>mdi-chevron-left</v-icon>
        </v-btn>
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense id="list-item">
        <v-list-item v-for="item in items" :key="item.title" link>
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content @click="goTo(item.title)">
            <v-list-item-title>{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
    
    <div id="main-cont" >
      <div class="row" style="margin-top:3%;">
        <div class="col-md-12">
          <div class="row">
             <div class="col-sm-3">
                 <div class="card">
                     <div class="card-body">
                         <h5 class="card-title mb-4">Supports</h5>
                         <h1 class="display-5 mt-1 mb-3">{{ support }}</h1>
                         <div class="mb-1">
                             <span class="text-danger"> <i class="mdi mdi-arrow-bottom-right"></i>  </span>
                             <span class="text-muted">Since last week</span>
                         </div>
                     </div>
                 </div>    
              </div>
              <div class="col-sm-3">
                  <div class="card">
                      <div class="card-body">
                          <h5 class="card-title mb-4">Opened Tickets</h5>
                          <h1 class="display-5 mt-1 mb-3">{{ open.length }}</h1>
                          <div class="mb-1">
                              <span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i>  </span>
                              <span class="text-muted">Since last week</span>
                          </div>
                      </div>
                  </div>
               </div>
              <div class="col-sm-3">
                  <div class="card">
                      <div class="card-body">
                          <h5 class="card-title mb-4">Pending Tickets</h5>
                          <h1 class="display-5 mt-1 mb-3">{{ pending.length }}</h1>
                          <div class="mb-1">
                              <span class="text-danger"> <i class="mdi mdi-arrow-bottom-right"></i>  </span>
                              <span class="text-muted">Since last week</span>
                          </div>
                      </div>
                  </div>
               </div>
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Closed Tickets</h5>
                            <h1 class="display-5 mt-1 mb-3">{{ closed.length }}</h1>
                            <div class="mb-1">
                                <span class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i> </span>
                                <span class="text-muted">Since last week</span>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
        </div>
      </div>

      <div>
        <router-view></router-view>
      </div>

    </div>
</div>
</template>

<script>
import { mapActions } from 'vuex';
export default {
  data() {
    return {
      open:[],
      closed: [],
      pending: [],
      support: [],
      tickets: [],
      drawer: true,
      items: [
        { title: "Tickets", icon: "mdi-pencil" },
        { title: "Priority", icon: "mdi-priority-high" },
        { title: "Status", icon: "mdi-list-status" },
        { title: "Moderators", icon: "mdi-account-group-outline" },
        { title: "Basic Users", icon: "mdi-account-group-outline" },
        { title: "Log Out", icon: "mdi-logout" },
      ],
      mini: true
    };
  },
  mounted(){
    this.showTicket()
    
    this.support = this.$store.state.allTickets.length
    
    this.getAllUser()
    this.getStatus()
    this.getPriority()
  },
	
  methods: {
    ...mapActions([
      'listallticket',
      'getAllUsers',
      'getAllPriority',
      'getAllStatus',
      'logout'
      ]),
      getStatus(){
        this.getAllStatus()
      },
      getPriority(){
        this.getAllPriority()
      },
      showTicket(){
        this.listallticket()
          .then(() => {
           
            this.tickets = this.$store.state.allTickets 
            this.support = this.tickets.length

            const openResult = this.$store.state.allTickets.filter(ticket => ticket.status_id == 1)
            this.open = [...openResult]

            console.log("All OPENED DD ", openResult)

            const pendingResult = this.$store.state.allTickets.filter(ticket => ticket.status_id == 3)
            this.pending = [...pendingResult]

            const closedResult = this.$store.state.allTickets.filter(ticket => ticket.status_id == 2)
            this.closed = [...closedResult]
          
          })
      },
      getAllUser(){
        this.getAllUsers()
          .then(() => {
            console.log("ALL USERS RETRIEVED")
          })
      },
    goTo(item){
      if(item == "Tickets"){
         this.$router.push({name: 'AdminHome'})
      }else if(item == "Priority"){
        this.$router.push({name: 'Priority'})
      }else if(item == "Status"){
        this.$router.push({name: 'Status'})
      }else if(item == "Moderators"){
        this.$router.push({name:'Moderator'})
      } else if(item == "Basic Users"){
        this.$router.push({name: 'Basics'})
      } else {
        this.logout()
          .then(() => {
             console.log("Log out")
             this.$router.push({name: 'Signin'});	
             console.log("ACCSS ", this.$store.state.accessToken)
             if(confirm("Are you sure, want to logout?")){
                location.reload();
             }
        })
      }
    }
  }
};
</script>

<style scoped>
#sidepanel {
  height: 100%;
}
#main-cont{
  height: 100%;
}
#list-item{
  margin-top: 20px;
}
.card {
    margin-bottom: 24px;
    margin-top: 6px;
    margin-left: 3px;
    margin-right: 3px;
    border:none;
    padding:0.6pc;
    box-shadow: 1px 3px 5px #d3cccc;
}
</style>
